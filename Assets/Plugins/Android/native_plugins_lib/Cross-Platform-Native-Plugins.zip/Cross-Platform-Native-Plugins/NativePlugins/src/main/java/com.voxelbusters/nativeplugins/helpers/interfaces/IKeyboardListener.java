package com.voxelbusters.nativeplugins.helpers.interfaces;

/**
 * Created by ayyappa on 02/12/17.
 */

public interface IKeyboardListener
{
    void onKeyboardVisibilityChange(boolean isVisible);
}

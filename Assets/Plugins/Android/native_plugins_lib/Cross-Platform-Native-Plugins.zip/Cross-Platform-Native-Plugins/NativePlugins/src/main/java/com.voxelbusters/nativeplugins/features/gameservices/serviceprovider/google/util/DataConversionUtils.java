package com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google.util;

import android.net.Uri;

import com.google.android.gms.games.Player;
import com.google.android.gms.games.achievement.Achievement;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.AchievementData;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.User;
import com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google.AchievementInfo;

/**
 * Created by ayyappa on 12/05/16.
 */
public class DataConversionUtils
{
    public static User getUser(Player player)
    {
        if (player == null)
            return new User();

        User user = new User();

        user.identifier = player.getPlayerId();
        user.name		= player.getDisplayName();
        user.alias		= player.getName(); // TODO check this param once.

        // Get high res image
        Uri highResImageUri = player.getHiResImageUri();
        if (highResImageUri != null)
        {
            user.highResImageUrl = highResImageUri.toString();
        }

        // Get Icon
        Uri iconImageUri = player.getIconImageUri();
        if (iconImageUri != null)
        {
            user.iconImageUrl = iconImageUri.toString();
        }

        user.timeStamp = player.getRetrievedTimestamp();

        return user;
    }

    public static AchievementData getAchievementData(AchievementInfo achievement)
    {
        AchievementData data = new AchievementData();

        data.identifier = achievement.identifier;
        data.name = achievement.name;
        data.unAchievedDescription = achievement.description;
        data.achievedDescription = "";
        data.imagePath = achievement.imagePath;
        data.type = achievement.getTypeForAchievement();
        data.currentSteps = achievement.currentSteps;
        data.totalSteps = achievement.totalSteps;
        data.state = achievement.getStateForAchievement();
        data.lastReportedDate = achievement.lastReportedDate;
        data.isCompleted = achievement.isCompleted;

        return data;

    }
}

package com.voxelbusters.nativeplugins.utilities;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.IOException;

/**
 * Created by ayyappa on 07/03/17.
 */
public class BitmapUtility {
    public static int getExifRotationForFile(String filePath)
    {
        ExifInterface exifData = null;
        try
        {
            exifData = new ExifInterface(filePath);
            int orientation = exifData.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            return exifToDegrees(orientation);

        }
        catch (Exception e)
        {
        }
        return 0;
    }

    public static int exifToDegrees(int exifOrientation) {
        if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
            return 90;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 180;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
            return 270;
        }
        return 0;
    }

}
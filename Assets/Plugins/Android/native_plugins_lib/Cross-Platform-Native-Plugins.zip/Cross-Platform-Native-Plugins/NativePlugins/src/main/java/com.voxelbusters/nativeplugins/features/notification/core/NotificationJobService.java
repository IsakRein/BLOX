package com.voxelbusters.nativeplugins.features.notification.core;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.JobIntentService;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.JSONUtility;

import org.json.JSONObject;

/**
 * Created by ayyappa on 09/02/18.
 */

public class NotificationJobService extends JobIntentService
{
    /**
     * Unique job ID for this service.
     */
    static final int JOB_ID = 1000;

    /**
     * Convenience method for enqueuing work in to this service.
     */
    public static void enqueueWork(Context context, Intent work) {
        enqueueWork(context, NotificationJobService.class, JOB_ID, work);
    }

    @Override
    protected void onHandleWork(Intent intent)
    {

        Bundle extras = intent.getExtras();
        GoogleCloudMessaging service = GoogleCloudMessaging.getInstance(this);

        String messageType = service.getMessageType(intent);

        Debug.log(CommonDefines.NOTIFICATION_TAG, "GCMIntentService received message type : " + messageType);

        if (!extras.isEmpty())
        {
            if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType))
            {
                // Post notification of received message.
                Debug.log(CommonDefines.NOTIFICATION_TAG, "GCM OnMessage : " + extras.toString());

                NotificationDispatcher dispatcher = new NotificationDispatcher(this);

                JSONObject notificationMap = JSONUtility.getJSONfromBundle(extras);
                dispatcher.dispatch(notificationMap, true);// Post the notification
            }
        }
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
    }

}


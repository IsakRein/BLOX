package com.voxelbusters.nativeplugins.features.medialibrary;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;

import com.voxelbusters.androidnativeplugin.R;
import com.voxelbusters.nativeplugins.utilities.BitmapUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by ayyappa on 05/03/17.
 */
public class CameraPictureActivity extends Activity
{
    //https://developer.android.com/guide/topics/media/camera.html

    private Camera                      mCamera;
    private CameraPreviewSurfaceView    mPreview;
    private String                      mCapturePath;
    private String                      TAG             = "CameraPictureActivity";

    private Camera.PictureCallback mPicture = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera)
        {
            if (data != null)
            {
                try
                {
                    FileOutputStream fos = new FileOutputStream(new File(mCapturePath));
                    fos.write(data);
                    fos.close();

                    Debug.log("Exif Orientation", "Exif : " + BitmapUtility.getExifRotationForFile(mCapturePath));

                    CameraPictureActivity.this.setResult(Activity.RESULT_OK);
                    CameraPictureActivity.this.finish();
                }
                catch (FileNotFoundException e)
                {
                    Log.d(TAG, "File not found: " + e.getMessage());
                }
                catch (IOException e)
                {
                    Log.d(TAG, "Error accessing file: " + e.getMessage());
                }
                finally
                {
                    CameraPictureActivity.this.setResult(Activity.RESULT_CANCELED);
                    CameraPictureActivity.this.finish();
                }
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.np_camera_picture_layout);

        Intent intent = getIntent();

        Uri uri = (Uri) intent.getExtras().getParcelable(MediaStore.EXTRA_OUTPUT);
        mCapturePath = uri.getPath();

        Debug.log(TAG, "Capture Path : " + mCapturePath);

        // Create an instance of Camera
        mCamera = getCameraInstance();

        if (mCamera != null) {

            // Create our Preview view and set it as the content of our activity.
            mPreview = new CameraPreviewSurfaceView(this, mCamera);
           // FrameLayout preview = (FrameLayout) findViewById(R.id.np_camera_picture_layout);
           // preview.addView(mPreview);

            // Move button view to top
            View button = findViewById(R.id.np_camera_capture_button);
            button.bringToFront();
        }
        else
        {
            finish();
        }
    }

    public Camera getCameraInstance()
    {
        Camera cam = null;

        int numberOfCameras = Camera.getNumberOfCameras();

        for (int i = 0; i < numberOfCameras; i++)
        {
            try {
                Debug.error("Camera Creation", "Trying to open camera instance");

                cam = Camera.open(i); // attempt to get a Camera instance

                Camera.Parameters parameters = cam.getParameters();
                Camera.Size bestSize = getBestPreviewSize(1024, 1024, parameters);

                if (bestSize!=null)
                {
                    parameters.setPreviewSize(bestSize.width, bestSize.height);
                    cam.setParameters(parameters);
                }

                int orientationAngle = getCameraOrientationValue(i);
                cam.setDisplayOrientation(orientationAngle);
                break;
            }
            catch (Exception e)
            {
                // Camera is not available (in use or does not exist)
                Debug.error("Camera Creation", "Can't create camera instance!" + e);
            }
        }


        return cam; // returns null if camera is unavailable
    }



    private  int getCameraOrientationValue (int cameraId)
    {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = this.getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0: degrees = 0; break;
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        return  result;
    }

    public void onCaptureCameraPicture(View view)
    {
        mCamera.takePicture(null, null, mPicture);
    }

    @Override
    public void onResume() {
        super.onResume();

        Debug.error("Camera onResume", "onResume");

        if (mCamera == null) {
            mCamera = getCameraInstance();
        }
    }

    @Override
    public void onPause()
    {
        Debug.error("Camera onPause", "onPause");

        releaseCamera();
        super.onPause();
    }
    private void releaseCamera()
    {
        if (mCamera != null)
        {
            mCamera.stopPreview();
            mCamera.release();        // release the camera for other applications
            mCamera = null;
        }
    }

    private Camera.Size getBestPreviewSize(int width, int height,
                                           Camera.Parameters parameters) {
        Camera.Size result=null;

        for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
            if (size.width<=width && size.height<=height) {
                if (result==null) {
                    result=size;
                }
                else {
                    int resultArea=result.width*result.height;
                    int newArea=size.width*size.height;

                    if (newArea>resultArea) {
                        result=size;
                    }
                }
            }
        }

        return(result);
    }
}
